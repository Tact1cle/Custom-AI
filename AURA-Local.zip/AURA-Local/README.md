# AURA Local

A separate browser-only AI edition. The existing AURA Cloud app is not modified.

## What it does
- Runs the open SmolLM2 360M Instruct ONNX model locally in the browser through Transformers.js.
- No API key, account, extension, Node.js, or backend is required on the Chromebook.
- Chats and personality settings are stored in the browser's local storage.
- Browser caching is enabled for model assets. The service worker caches the app shell for repeat visits.
- Friendly, Balanced, Creative, Tutor, and Builder personalities, custom instructions, chat export/delete, and mobile layout.

## Important Chromebook limitation
This is a small model suitable for experimentation, not a replacement for a large cloud AI. The first visit needs internet to download the JavaScript runtime and model weights (the model can take hundreds of MB depending on the files served). Browser cache can be cleared/evicted, and full offline use is only available after all needed assets have cached successfully. Some managed school Chromebooks block Hugging Face/CDN domains, disable WebGPU, or restrict storage. If policy blocks the required downloads or browser APIs, the app cannot bypass that policy.

## Run it without extensions
Because browser module imports, service workers, and model caching have origin/security requirements, do not open `index.html` directly as a `file://` URL. Publish this folder as a static HTTPS site (for example, a school-approved static host) and visit that URL in Chrome. No extensions are needed. GitHub Pages is one option only if your school allows it. On the first visit, keep the page open while the model downloads and loads. Then test airplane mode/reload to see whether this browser cached all required files.

## Model and runtime
- Model: `onnx-community/SmolLM2-360M-ONNX` (open model hosted on Hugging Face)
- Runtime: Transformers.js v3.7.2 from jsDelivr
- Inference preference: WebGPU when `navigator.gpu` exists; WASM fallback otherwise.

The app may need small compatibility adjustments on older/managed ChromeOS devices. The current browser's available GPU is only a rough compatibility signal; it does not guarantee the model will load.
